# Tripletex

Sync Data

**Table of Contents**

- Configuration
- Usage
- Dependencies
- Issues & Bugs
- Development

---

## Configuration

### Product Sync
#### Basic Information

- Synced only those fields with Tripletex that are available in the Tripletex.
- Field which is sync
  - name -> name
  - Reference -> product number
  - uom -> Product Unit
  - Internal notes -> Product Description
  - Sale Orderline Description -> Orderline Description
  - Cost Price -> Purchase Price
  - Selling -> Selling Price
  - Vendor -> Suppliers

#### Create & Write & Unlink

- When creating a product, ensure it's created in Tripletex with the necessary data required for invoicing.
- And When update the data then all data which is in tripletex that is updated.
- When a product is deleted in Odoo, it is also deleted from Tripletex.

#### product sync to odoo

- for update the product in tripletex product id and default code is required.
- And product have a resale product (supplier in tripletex) then update the vendor in odoo in purchase tab.
- When multiple vendors are linked to a product in odoo, the newly synced vendor from Tripletex is always placed first in seller_ids.

#### import Odoo to Tripletex:

- When create a product reference number is required and for product uom common code is require.
- Ensured each common code maps to only one UoM.
- some common code which is support tripletex(aa,bb,qq,ww)
- For uom creation in Tripletex, Tripletex expects the common code to be a recognized UN/CEFACT unit code.
- If Not valid then uom not create in tripletex.
- Synced vendor in product with Tripletex only if the selected vendor has valid Tripletex-compatible data.

#### import Tripletex to Odoo:

- When import the product from tripletex check the tripletex number with reference number if not exist than created.
- If uom not in odoo than created under the general category because of creation of uom category is required and common code update with Tripletex product uom common code.
- If supplier is selected in the product then sync in product else not sync.

### Customer Sync
#### For Odoo to Tripletex:

- When create a customer than email is require for creation in tripletex because invoice email is require in tripletex.
- When create customer from sale or contacts then create a customer in Tripletex.
- When create vendor from purchase then create a customer/supplier in Tripletex. 
- Import customer from odoo if customer have a trip_customer value.

#### For Tripletex to Odoo:

- Import from Tripletex if customer type is customer and customer/supplier then we should we import using customer and if
  type is supplier then crated in vendor(supplier_rank = 1).

## Usage

- Sync product from Odoo to Tripletex and Tripletex to Odoo.
- Import product from Odoo to Tripletex and Tripletex to Odoo.

---

## Dependencies

### Python library dependencies

- This module have from `BeautifulSoup` python dependencies 
- BeautifulSoup used for web scraping — specifically, for parsing HTML and XML documents.

---

## Development

* Inherited `product.template` model
* Inherited method `create` in product.template.
* Inherited method `write` in product.template.
* Inherited method `unlink` in product.template.

